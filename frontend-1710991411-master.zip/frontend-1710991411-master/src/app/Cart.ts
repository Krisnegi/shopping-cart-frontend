import {Product} from './Product';
import {User} from './User';
export class Cart{
constructor(id:Number,products:Product,user:User,quantity:Number){}
}
