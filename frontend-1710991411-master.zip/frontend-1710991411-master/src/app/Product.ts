export class Product
{
constructor(id:Number,name:string,price:Number,img:string,category:string,details:string){}
}
